package com.javed.githubsearcher.activity

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.javed.githubsearcher.adapter.UserListAdapter
import com.javed.githubsearcher.common.AppController
import kotlinx.android.synthetic.main.activity_first_screen.*
import org.json.JSONArray


class FirstScreen : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.javed.githubsearcher.R.layout.activity_first_screen)
        defineViews()
    }

    private fun defineViews() {
        et_search.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun afterTextChanged(s: Editable) {
                callAPI(s.toString())
            }
        })
    }

    private fun callAPI(iText: String) {
        if (isNetworkAvailable()) {
            val url = "https://api.github.com/users?since=$iText"
            val request = object : JsonArrayRequest(Method.GET, url, null,
                Response.Listener { response ->
                    val responseJson = response as JSONArray
                    callAdapter(responseJson)
                },
                Response.ErrorListener { error ->
                    errorHandler(error)
                }
            ) {

            }
            AppController.getInstance(this@FirstScreen).addToRequestQueue(request)
        } else {
            networkNotAvailable()
        }
    }

    private fun callAdapter(userList: JSONArray) {
        rv_users.layoutManager = LinearLayoutManager(this)
        rv_users.adapter = UserListAdapter(this, userList)
    }
}
