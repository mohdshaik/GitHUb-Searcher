package com.javed.githubsearcher.activity

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.VolleyError

open class BaseActivity : AppCompatActivity() {

    fun errorHandler(error: VolleyError) {
        Log.d("-GitHub Searcher-", "Error -> " + error.printStackTrace())
    }

    fun networkNotAvailable() {
        Toast.makeText(this, "Network Not Available!", Toast.LENGTH_SHORT).show()
    }

    fun isNetworkAvailable(): Boolean {
        val cm = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: NetworkInfo? = cm.activeNetworkInfo
        return activeNetwork?.isConnected ?: false
    }

    @Suppress("unused")
    fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
