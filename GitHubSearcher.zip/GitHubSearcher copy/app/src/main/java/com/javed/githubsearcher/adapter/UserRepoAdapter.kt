package com.javed.githubsearcher.adapter

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.javed.githubsearcher.R
import com.javed.githubsearcher.activity.SecondScreen
import kotlinx.android.synthetic.main.cv_user_repository.view.*
import org.json.JSONArray


class UserRepoAdapter(
    private val activity: SecondScreen,
    private val repos: JSONArray
) :
    RecyclerView.Adapter<RepoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): RepoViewHolder {
        return RepoViewHolder(
            LayoutInflater.from(activity).inflate(
                R.layout.cv_user_repository,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return repos.length()
    }

    override fun onBindViewHolder(viewHolder: RepoViewHolder, position: Int) {
        val repo = repos.getJSONObject(position)
        viewHolder.cvRepo.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(repo.getString("html_url")))
            activity.startActivity(intent)
        }
        viewHolder.tvUserName.text = repo.getString("name")
        val forks = repo.getString("forks_count") + " Forks"
        viewHolder.tvForks.text = forks
        val stars = repo.getString("stargazers_count") + " Stars"
        viewHolder.tvStars.text = stars
    }
}

class RepoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val tvUserName = view.tv_repo_name!!
    val tvForks = view.tv_forks!!
    val tvStars = view.tv_stars!!
    val cvRepo = view.cv_repo!!
}