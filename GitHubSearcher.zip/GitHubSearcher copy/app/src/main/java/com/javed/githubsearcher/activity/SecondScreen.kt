package com.javed.githubsearcher.activity

import android.graphics.Bitmap
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Response
import com.android.volley.toolbox.ImageRequest
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.javed.githubsearcher.R
import com.javed.githubsearcher.adapter.UserRepoAdapter
import com.javed.githubsearcher.common.AppController
import kotlinx.android.synthetic.main.activity_second_screen.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

class SecondScreen : BaseActivity() {
    var userUrl = ""
    var imageUrl = ""
    var arrRepo: JSONArray = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_screen)
        getIntentData()
        defineViews()
    }

    private fun getIntentData() {
        if (intent.hasExtra("userUrl")) {
            userUrl = intent.getStringExtra("userUrl")
            loadUser()
        }
        if (intent.hasExtra("imageUrl")) {
            imageUrl = intent.getStringExtra("imageUrl")
            loadImage()
        }
    }

    private fun loadImage() {
        prg_bar.visibility = VISIBLE
        val imageRequest = ImageRequest(imageUrl,
            Response.Listener { response ->
                prg_bar.visibility = GONE
                if (response != null) {
                    iv_avatar.setImageBitmap(response)
                }
            },
            200,
            200,
            ImageView.ScaleType.CENTER_CROP,
            Bitmap.Config.ARGB_8888,
            Response.ErrorListener { error ->
                prg_bar.visibility = GONE
                errorHandler(error)
            }
        )
        AppController.getInstance(this).addToRequestQueue(imageRequest)
    }

    private fun defineViews() {
        iv_back.setOnClickListener { finish() }
        et_search.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun afterTextChanged(s: Editable) {
                filter(s.toString())
            }
        })
    }

    private fun loadUser() {
        val request = object : JsonObjectRequest(
            Method.GET, userUrl, null,
            Response.Listener { response ->
                val responseJson = JSONObject(response.toString())
                if (responseJson.getString("name") != "null") {
                    tv_user_name.visibility = VISIBLE
                    tv_user_name.text = responseJson.getString("name")
                } else {
                    tv_user_name.visibility = GONE
                }
                if (responseJson.getString("email") != "null") {
                    tv_email.visibility = VISIBLE
                    tv_email.text = responseJson.getString("email")
                } else {
                    tv_email.visibility = GONE
                }
                if (responseJson.getString("location") != "null") {
                    tv_location.visibility = VISIBLE
                    tv_location.text = responseJson.getString("location")
                } else {
                    tv_location.visibility = GONE
                }
                if (responseJson.getString("created_at") != "null") {
                    tv_join_date.visibility = VISIBLE
                    val date =
                        responseJson.getString("created_at").replace("T", " ").replace("Z", "")
                    tv_join_date.text = date
                } else {
                    tv_join_date.visibility = GONE
                }
                val followers = responseJson.getString("followers") + " Followers"
                tv_followers.text = followers
                val following = "Following ${responseJson.getString("following")}"
                tv_following.text = following

            },
            Response.ErrorListener { error ->
                errorHandler(error)
            }
        ) {

        }
        AppController.getInstance(this).addToRequestQueue(request)
        getRepo()
    }

    private fun getRepo() {
        val url = "$userUrl/repos"
        val request = object : JsonArrayRequest(
            Method.GET, url, null,
            Response.Listener { response ->
                arrRepo = response as JSONArray
            },
            Response.ErrorListener { error ->
                errorHandler(error)
            }
        ) {

        }
        AppController.getInstance(this@SecondScreen).addToRequestQueue(request)
    }

    private fun filter(iText: String) {
        val finalArray = JSONArray()
        for (i in 0 until arrRepo.length()) {
            val temp = arrRepo.getJSONObject(i)
            if (temp.getString("name").toLowerCase(Locale.US).startsWith(iText.toLowerCase(Locale.US))) {
                finalArray.put(temp)
            }
        }
        if (finalArray.length() > 0) {
            callAdapter(finalArray)
        } else {
            //Todo
            //showToast("No Repository found!")
            Log.d("-GitHub Searcher-", "No Repository found!")
        }

    }

    private fun callAdapter(repoList: JSONArray) {
        rv_repo.layoutManager = LinearLayoutManager(this)
        rv_repo.adapter = UserRepoAdapter(this, repoList)
    }
}
