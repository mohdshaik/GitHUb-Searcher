package com.javed.githubsearcher.activity

import android.os.Bundle
import com.javed.githubsearcher.R

class Login : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
    }
}
