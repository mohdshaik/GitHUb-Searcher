package com.javed.githubsearcher.adapter

import android.content.Intent
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.ImageRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.javed.githubsearcher.R
import com.javed.githubsearcher.activity.FirstScreen
import com.javed.githubsearcher.activity.SecondScreen
import com.javed.githubsearcher.common.AppController
import kotlinx.android.synthetic.main.cv_users.view.*
import org.json.JSONArray
import org.json.JSONObject

class UserListAdapter(
    private val activity: FirstScreen,
    private val users: JSONArray
) :
    RecyclerView.Adapter<ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(activity).inflate(
                R.layout.cv_users,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return users.length()
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val user = users.getJSONObject(position)
        viewHolder.cvUser.setOnClickListener {
            if (activity.isNetworkAvailable()) {
                val intent = Intent(activity, SecondScreen::class.java)
                intent.putExtra("userUrl", user.getString("url"))
                intent.putExtra("imageUrl", user.getString("avatar_url"))
                activity.startActivity(intent)
            } else {
                activity.networkNotAvailable()
            }
        }
        val request = object : JsonObjectRequest(
            Method.GET, user.getString("url"), null,
            Response.Listener { response ->
                val responseJson = JSONObject(response.toString())
                viewHolder.tvUserName.text = responseJson.getString("name")
                val repo = "Repo: " + responseJson.getString("public_repos")
                viewHolder.tvRepo.text = repo

            },
            Response.ErrorListener { error ->
                activity.errorHandler(error)
            }
        ) {

        }
        AppController.getInstance(activity).addToRequestQueue(request)

        viewHolder.prgBar.visibility = View.VISIBLE
        val imageRequest = ImageRequest(user.getString("avatar_url"),
            Response.Listener { response ->
                viewHolder.prgBar.visibility = View.GONE
                if (response != null) {
                    viewHolder.ivUser.setImageBitmap(response)
                }
            },
            200,
            200,
            ImageView.ScaleType.CENTER_CROP,
            Bitmap.Config.ARGB_8888,
            Response.ErrorListener { error ->
                viewHolder.prgBar.visibility = View.GONE
                activity.errorHandler(error)
            }
        )
        AppController.getInstance(activity).addToRequestQueue(imageRequest)
    }
}

class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val ivUser = view.iv_user!!
    val prgBar = view.prg_bar!!
    val tvUserName = view.tv_user_name!!
    val tvRepo = view.tv_repo!!
    val cvUser = view.cv_user_repo!!
}